<div align="center">
 <br>

Discord Bot list
=================

![](https://its.xill.services/i/otmhs.gif)
</div>


# About

This botlist is discontinued and no longer exists. You can always create your own copy of it from this source code.

# Features

This botlist is still being updated, but here's a list of current features:
 - Bot resubmit option
 - Bot Widget
 - Markdown descriptions
 - Nice minimalist website (with dark theme)
 - Search option
 - Easy setup (all customisation features in one file)
 - Discord bot with many commands
 - Server count API

# Contributing

You want to contribute? Go ahead and make a pull request and I'll look into it as soon as I can. 


# Copying

No problem, just check the [`LICENSE.md`](https://github.com/Ankrad/discordbotlist/blob/master/LICENSE.md) before you forking it.
Check the [wiki](https://github.com/Ankrad/Discord-Bot-List/wiki) for a setup guide

